import java.util.Scanner;

public class Main1 {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        System.out.print("Введите первое число:");
        int num1 = scan.nextInt();

        System.out.print("Введите второе число:");
        int num2 = scan.nextInt();

        System.out.print("Введите второе число:");
        int num3 = scan.nextInt();

        int sum = num1 + num2 + num3;

        System.out.print("Сумма чисел равна:" + sum);


    }
}
