import interfaces.LibrarianInterface;

public class Lbrarian extends LibraryUsers implements LibrarianInterface {

    @Override
    public void orderbook() {
        System.out.println("Заказал книгу.");
    }
}
