import interfaces.AdmainInterface;

public class Administrator extends LibraryUsers implements AdmainInterface{
    @Override
    public void findgive() {
        System.out.println("Нашел и выдал книгу.");
    }

    @Override
    public void notifybook() {
        System.out.println("Уведомил о просрочке.");
    }
}
