package interfaces;

public interface LibrarianInterface {
    void orderbook();
}
