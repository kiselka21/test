package interfaces;

public interface DeliverInterface {
    void supply();
}
