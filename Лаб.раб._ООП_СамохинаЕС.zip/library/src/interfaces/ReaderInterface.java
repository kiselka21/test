package interfaces;

public interface ReaderInterface {
    void takebook();
    void returnbook();
}
