package interfaces;

public interface AdmainInterface {
    void findgive();
    void notifybook();
}
