import interfaces.DeliverInterface;

public class Deliver extends LibraryUsers implements DeliverInterface{
    @Override
    public void supply() {
        System.out.println("Поставил книги в библиотеку.");
    }
}