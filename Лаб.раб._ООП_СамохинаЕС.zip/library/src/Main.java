public class Main {
    public static void main(String[] args) {

        Deliver deliver = new Deliver();
        deliver.supply();

        Lbrarian librarian = new Lbrarian();
        librarian.orderbook();

        Administrator administrator = new Administrator();
        administrator.findgive();
        administrator.notifybook();

        Reader reader = new Reader();
        reader.returnbook();
        reader.takebook();



    }

}
