import interfaces.ReaderInterface;

public class Reader extends LibraryUsers implements ReaderInterface {
    @Override
    public void takebook() {
        System.out.println("Взял книгу");
    }

    @Override
    public void returnbook() {
        System.out.println("Вернул книгу");
    }
}
