public class Runner implements Runnable {

     int i;
     int s;

    @Override
    public void run() {
        for(int number = 1; number<=100; number++)
        {
            if(number % 10 == 0) {
                System.out.println(number);
            }
        }


        try {
            Thread.sleep(5000);
        } catch (InterruptedException e){
            e.printStackTrace();
        }
        System.out.println("Hello World!");
    }


}