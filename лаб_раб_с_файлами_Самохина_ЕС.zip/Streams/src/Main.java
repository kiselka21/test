import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException {
        String str = new String();
        str = ("Hello World!)");
        String str2 = new String();
        int count = 0;

        FileOutputStream fos= new FileOutputStream("C:/Users/edgar/Documents/text.txt");
        FileOutputStream fos2= new FileOutputStream("C:/Users/edgar/Documents/text2.txt");
        byte[]buffer = str.getBytes();
        byte[]buffer2;
        fos.write(buffer);

        FileInputStream fin = new FileInputStream("C:/Users/edgar/Documents/text.txt");


        int i = -1;
        while ((i = fin.read())!= -1){
            str2 = String.valueOf((char)i);
           buffer2 = str2.getBytes();
           fos2.write(buffer2);
           count++;
        }
        System.out.println(count);
        str2 = String.valueOf(count);
        buffer2 = str2.getBytes();
        fos2.write(buffer2);
        fin.close();
    }
}
