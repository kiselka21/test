import java.io.*;
public class Main {
    public static void main(String[] args) throws IOException {
        FileWriter writer = new FileWriter("C://Users/samdd/YandexDisk/����� ����/1288.txt", true);
        String text = "Hello Donald Macdonald!";
        writer.write(text);
        writer.close();

        FileReader reader = new FileReader("C://Users/samdd/YandexDisk/����� ����/1288.txt");
        int c;

        while ((c=reader.read()) != -1){
            System.out.print((char) c);
        }

    }
}
