public class HelloWorld {
    public static void main(String[] args) {
    int c = 56;
final int LOVE =3;
  System.out.println(LOVE);


}
}
