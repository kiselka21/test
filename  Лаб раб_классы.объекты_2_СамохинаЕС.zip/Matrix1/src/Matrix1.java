import javax.sql.rowset.serial.SQLOutputImpl;

public class Matrix1 {


    public static float [][] sumMatrix(float[][] oil, float[][] door) {
        float[][] sum = new float[3][3];
        for (int i = 0; i < oil.length; i++) {
            for (int j = 0; j < door.length; j++) {
                sum[i][j] = oil[i][j] + door[i][j];
            }
        }
        return sum;
    }
    public  static int b = 8;
    public static float  [][] multib (float [][] oil, int b) {
        for (int i = 0; i < oil.length; i++) {
            for (int j = 0; j < oil.length; j++) {

                oil[i][j] = oil[i][j] * b;
                System.out.println();


                break;
            }
        }
        return oil;
    }

    public static void print(float[][] itog) {
        for(int i=0;i<itog.length;i++){
            for(int j=0;j<itog[0].length;j++){
                System.out.print(itog[i][j] + " ");
            }
            System.out.println();
        }
    }




    public static void main(String[] args) {

         float [][] oil = new float[3][3];

        oil [0][0] = 6;
        oil [0][1] = 8;
        oil [0][2] = 2;
        oil [1][0] = 3;
        oil [1][1] = 1;
        oil [1][2] = 7;
        oil [2][0] = 10;
        oil [2][1] = 5;
        oil [2][2] = 4;

        float [][] door = new float[3][3];

        door [0][0] = 7;
        door [0][1] = 0;
        door [0][2] = 3;
        door [1][0] = 6;
        door [1][1] = 10;
        door [1][2] = 1;
        door [2][0] = 5;
        door [2][1] = 9;
        door [2][2] = 2;


        float[][] sum = sumMatrix(oil, door);
        print(sum);

        float[][] multi = multib(oil,b);
        print(multi);
    }

}
