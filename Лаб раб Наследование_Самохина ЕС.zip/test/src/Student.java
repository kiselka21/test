import java.util.Random;

public class Student {

        public static void main(String[] args) {
                String firstName, lastName, group;
                Student[] studentArray = new Student[10];

                studentArray[0] =  new Aspirant();
                studentArray[1] =  new Aspirant();
                studentArray[2] =  new Aspirant();
                studentArray[3] =  new Aspirant();
                studentArray[4] =  new Aspirant();
                studentArray[5] =  new Student();
                studentArray[6] =  new Student();
                studentArray[7] =  new Student();
                studentArray[8] =  new Student();
                studentArray[9] =  new Student();

                for(int i = 0; i < studentArray.length; i++) {
                        int x = (int) ((Math.random() * ((5 - 1) + 1)) + 1);
                        System.out.println(studentArray[i].getScholarship(x));
                }
        }

        public double getScholarship(double averageMark) {
                if (averageMark == 5) {
                        return  100;
                } else {
                        return 80;
                }

        }
}