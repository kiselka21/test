public class mnogim {
    public static void main(String[] args) {
        int i = 1;
        int[][] sol = new int[11][11];
        sol[0][0] = 0;
        sol[1][1] = 1;
        sol[2][2] = 2;
        sol[3][3] = 3;
        sol[4][3] = 4;
        sol[5][4] = 5;
        sol[6][5] = 6;
        sol[7][7] = 7;



        for ( i = 0; i < sol.length; i++) {

            System.out.printf("       �����     " +i);

        }
        System.out.println();
        int x = 1;
        int[][] made = new int[8][8];
        made[0][0] = 0;
        made[1][1] = 7;
        made[2][2] = 6;
        made[3][3] = 5;
        made[4][4] = 4;
        made[5][5] = 3;
        made[6][6] = 2;
        made[7][7] = 1;


        for ( x = 0; x < sol.length; x++) {

            System.out.printf("       �����     "+ made[1][1])
            ;
        }
        System.out.println();

        int z = 1;
        for ( z = 0; z < sol.length; z++) {
            int boom[]= new int [11];
            boom [1]=1*7;
            boom [2]=2*7;
            boom [3]=3*7;
            boom [4]=4*7;
            boom [5]=5*7;
            boom [6]=6*7;
            boom [7]=7*7;
            boom [8]=8*7;
            boom [9]=9*7;
            boom [10]=10*7;
            System.out.printf(" ������������:   " + boom[z]);
        }
        System.out.println();



    }
}
