public class Person {
    public Person() {
    }

    public Person( String fullName, int age) {
    }

    public static void main(String[] args) {
        Person person = new Person();
        Person person2 = new Person("Person",30);
        person.talk();
        person2.talk();
    }

    public void talk () {
        System.out.println("����-�� Person �������" );
    }

    public void move() {
    }
}